
import PrinceSunHome from "../components/PrinceSunHome"
export default function Home() {
  return <PrinceSunHome />
}
